
#ifndef __DS3231_H
#define	__DS3231_H
 
/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
 
extern char DS3231_Time[]; 
 

 
 
/* DS3231 ��ַ���� */
#define DS3231_ADDRESS 		 0xD0   
 
 
/*�ȴ���ʱʱ��*/
#define I2CT_FLAG_TIMEOUT         ((uint32_t)0x1000)
#define I2CT_LONG_TIMEOUT         ((uint32_t)(10 * I2CT_FLAG_TIMEOUT))
 
 
/*��Ϣ���*/
#define DS3231_DEBUG_ON         0
 
#define DS3231_INFO(fmt,arg...)           printf("<<-DS3231-INFO->> "fmt"\n",##arg)
#define DS3231_ERROR(fmt,arg...)          printf("<<-DS3231-ERROR->> "fmt"\n",##arg)
#define DS3231_DEBUG(fmt,arg...)          do{\
                                          if(DS3231_DEBUG_ON)\
                                          printf("<<-DS3231-DEBUG->> [%d]"fmt"\n",__LINE__, ##arg);\
                                          }while(0)
 
/* DS3231�Ĵ�����ַ */
																					
#define							DS3231_SECOND							    0x00    //��
#define 						DS3231_MINUTE      						    0x01    //��
#define 						DS3231_HOUR        						    0x02    //ʱ
#define 						DS3231_WEEK         					    0x03    //����
#define 						DS3231_DAY          					    0x04    //��
#define 						DS3231_MONTH                      			0x05    //��
#define             			DS3231_YEAR         						0x06    //��
/* ����1 */          
#define             			DS3231_SALARM1ECOND                         0x07    //��
#define 						DS3231_ALARM1MINUTE                         0x08    //��
#define             			DS3231_ALARM1HOUR                           0x09    //ʱ
#define 						DS3231_ALARM1WEEK  							0x0A    //����/��
/* ����2 */
#define 						DS3231_ALARM2MINUTE 						0x0b    //��
#define 						DS3231_ALARM2HOUR                           0x0c    //ʱ
#define 						DS3231_ALARM2WEEK                           0x0d    //����/��
 
#define 						DS3231_CONTROL                              0x0e    //���ƼĴ���
#define 						DS3231_STATUS                               0x0f    //״̬�Ĵ���
#define 						BSY                 					    2       //æ
#define 						OSF                							7       //����ֹͣ��־
#define 						DS3231_XTAL         						0x10    //�����ϻ��Ĵ���
#define 						DS3231_TEMPERATUREH 						0x11    //�¶ȼĴ������ֽ�(8λ)
#define 						DS3231_TEMPERATUREL 						0x12    //�¶ȼĴ������ֽ�(��2λ) 																				



/* Exported functions ------------------------------------------------------- */																				
void DS3231_Init(void);																																									
void DS3231_WriteReg(uint8_t RegAddress, uint8_t Data);
uint8_t DS3231_ReadReg(uint8_t RegAddress);
void I2C_WaitDs3231StandbyState(void);  																				
uint8_t BCD_DEC(u8 val);		
uint8_t DEC_BCD(u8 val);
 

void I2C_DS3231_SetTime(void);

void I2C_DS3231_getTime(void);

#endif   /* __DS3231_H */
 
 
 
