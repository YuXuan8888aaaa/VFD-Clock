#include "stm32f10x.h"                  // Device header
#include "Delay.h"

unsigned char LEDFlash;

void LED_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);	
	
	GPIO_InitTypeDef GPIO_InitStructurer;					
	
	GPIO_InitStructurer.GPIO_Mode = GPIO_Mode_Out_PP;		
	GPIO_InitStructurer.GPIO_Pin = GPIO_Pin_13;			    
	GPIO_InitStructurer.GPIO_Speed = GPIO_Speed_50MHz;		
	/*GPIO��ʼ��*/
	GPIO_InitTypeDef GPIO_InitStructure;					
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;		
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2|GPIO_Pin_3;	
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		
	
	GPIO_Init(GPIOA, &GPIO_InitStructure);					
	GPIO_Init(GPIOC, &GPIO_InitStructurer);					
}

void LED_All_ON(void)
{
	GPIO_SetBits(GPIOA, GPIO_Pin_3);	
	GPIO_SetBits(GPIOA, GPIO_Pin_2);
	GPIO_SetBits(GPIOC, GPIO_Pin_13);	  
}

void LED_All_OFF(void)
{
	GPIO_ResetBits(GPIOA, GPIO_Pin_3);	
	GPIO_ResetBits(GPIOA, GPIO_Pin_2);
	GPIO_ResetBits(GPIOC, GPIO_Pin_13);	  
}



void LED_All_Flicker(void)
{   
	uint32_t i;
	for (i = 0; i <100000; i++)
    {
      LED_All_OFF();
      Delay_us(10);
      LED_All_ON();
      Delay_us(10);
    }
}

