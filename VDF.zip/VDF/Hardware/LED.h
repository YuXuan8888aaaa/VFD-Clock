#ifndef __LED_H
#define __LED_H

void LED_Init(void);
void LED_All_ON(void);
void LED_All_OFF(void);
void LED_All_Flicker(void);

#endif

