#include "stm32f10x.h"                  // Device header
#include "Delay.h"

#define S_CS  GPIO_Pin_15
#define S_DIN GPIO_Pin_14
#define S_CLK GPIO_Pin_13
#define S_RST GPIO_Pin_12
#define S_EN  GPIO_Pin_5


void VFD_IO_INIT(void){
	
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB , ENABLE);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15; 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOB,&GPIO_InitStructure);
	    
	GPIO_ResetBits(GPIOB,S_RST);
    Delay_ms(5);
	GPIO_SetBits(GPIOB,S_RST);
    Delay_ms(5);
    GPIO_SetBits(GPIOB,S_EN);	   
}

void write_6302(unsigned char w_data)
{
  unsigned char i;
  for (i = 0; i < 8; i++)
  {
		GPIO_ResetBits(GPIOB,S_CLK);
    if ( (w_data & 0x01) == 0x01)
    {
      GPIO_SetBits(GPIOB,S_DIN);
    }
    else
    {
      GPIO_ResetBits(GPIOB,S_DIN);
    }
		Delay_us(10);
    w_data >>= 1;
    GPIO_SetBits(GPIOB,S_CLK);
		Delay_us(10);
  }
}
void VFD_cmd(unsigned char command)
{
  GPIO_ResetBits(GPIOB,S_CS);
  write_6302(command);
  GPIO_SetBits(GPIOB,S_CS);
	Delay_ms(1);
}

void VFD_Init(void)
{
  //SET HOW MANY digtal numbers
  GPIO_ResetBits(GPIOB,S_CS);
  write_6302(0xe0);
	Delay_ms(1);
  write_6302(0x07);//8 digtal
  GPIO_SetBits(GPIOB,S_CS);
	Delay_ms(1);
  //set bright
  GPIO_ResetBits(GPIOB,S_CS);
  write_6302(0xe4);
	Delay_ms(1);
  write_6302(0xff);//leve 255 max
  GPIO_SetBits(GPIOB,S_CS);
	Delay_ms(1);
}
void S0801_Brightness(unsigned char br){
GPIO_ResetBits(GPIOB,S_CS);
  write_6302(0xe4);
	Delay_ms(1);
  write_6302(br);//leve 255 max
  GPIO_SetBits(GPIOB,S_CS);
	Delay_ms(1);

}

void S0801_show(void)
{
  GPIO_ResetBits(GPIOB,S_CS);//��ʼ����
  write_6302(0xe8);     //��ַ�Ĵ�����ʼλ��
  GPIO_SetBits(GPIOB,S_CS); //ֹͣ����
}

void S0801_WriteOneChar(unsigned char x, unsigned char chr)
{
  GPIO_ResetBits(GPIOB,S_CS);  //��ʼ����
  write_6302(0x20 + x); //��ַ�Ĵ�����ʼλ��
  write_6302(chr + 0x30);
  GPIO_SetBits(GPIOB,S_CS); //ֹͣ����
  S0801_show();
}

void S0801_WriteStr(unsigned char x, char *str)
{
  GPIO_ResetBits(GPIOB,S_CS);  //��ʼ����
  write_6302(0x20 + x); //��ַ�Ĵ�����ʼλ��
  while (*str)
  {
    write_6302(*str); //ascii���Ӧ�ַ���ת��
    str++;
  }
  GPIO_SetBits(GPIOB,S_CS); //ֹͣ����
  S0801_show();
}

/**
  * @brief  S0801�η�����
  * @retval ����ֵ����X��Y�η�
  */
uint32_t S0801_Pow(uint32_t X, uint32_t Y)
{
	uint32_t Result = 1;
	while (Y--)
	{
		Result *= X;
	}
	return Result;
}

/**
  * @brief  S0801��ʾ���֣�ʮ���ƣ�������
  * @param  Line ��ʼ��λ�ã���Χ��1~4
  * @param  Column ��ʼ��λ�ã���Χ��1~16
  * @param  Number Ҫ��ʾ�����֣���Χ��0~4294967295
  * @param  Length Ҫ��ʾ���ֵĳ��ȣ���Χ��1~10
  * @retval ��
  */
void S0801_ShowNum( uint8_t Column, uint32_t Number, uint8_t Length)
{
	uint8_t i;
	for (i = 0; i < Length; i++)							
	{
		S0801_WriteOneChar( Column + i,Number / S0801_Pow(10, Length - i - 1) % 10);
	}
}


