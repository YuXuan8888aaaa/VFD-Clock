#ifndef __VFD_H
#define __VFD_H
#include "stm32f10x.h"                  // Device header



void VFD_IO_INIT(void);
//void VFD_IO_START(void);
void VFD_Init(void);
void VFD_cmd(unsigned char command);
void S0801_show(void);
void S0801_Brightness(unsigned char br);                        //����0-255
void S0801_WriteOneChar(unsigned char x, unsigned char chr);    //0-7�ַ������
void S0801_WriteStr(unsigned char x, char *str);                //0-7�ֽ�λ���
void S0801_ShowNum( uint8_t Column, uint32_t Number, uint8_t Length);


#endif
