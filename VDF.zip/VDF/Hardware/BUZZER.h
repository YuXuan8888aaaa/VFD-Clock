#ifndef __BUZZER_H
#define __BUZZER_H


#define BUZZER_GPIO_PORT	 GPIOA			            /* GPIO�˿� */
#define BUZZER_RCC 	         RCC_APB2Periph_GPIOA		/* GPIO�˿�ʱ�� */
#define BUZZER_PIN		     GPIO_Pin_1	

void BUZZER_Init(void);

void BUZZER_ON(void);
void BUZZER_OFF(void);
void BUZZ_P1(void );
void BUZZ_P11(void );
#endif

