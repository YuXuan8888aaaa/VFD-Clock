#include "BUZZER.h"
#include "stm32f10x.h"                  // Device header
#include "Delay.h"
void BUZZER_Init(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;

	RCC_APB2PeriphClockCmd(BUZZER_RCC, ENABLE);	 //ʹ�ܶ˿�ʱ��

	GPIO_InitStructure.GPIO_Pin = BUZZER_PIN;	 //�����������
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 //�������
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;//�ٶ�50MHz
	
	GPIO_Init(BUZZER_GPIO_PORT, &GPIO_InitStructure);	 //��ʼ��GPIO
    GPIO_SetBits(GPIOA, GPIO_Pin_1);
}

void BUZZER_ON(void)
{
	GPIO_ResetBits(GPIOA, GPIO_Pin_1);		//����PA1����Ϊ�͵�ƽ
}


void BUZZER_OFF(void)
{
	GPIO_SetBits(GPIOA, GPIO_Pin_1);		//����PA1����Ϊ�ߵ�ƽ
}

void BUZZ_P1(void )
{
	uint16_t i;
	for (i = 0; i <300; i++)
    {
      BUZZER_ON();
      Delay_us(300);
      BUZZER_OFF();
      Delay_us(300);
    }
}

void BUZZ_P11(void )
{
	uint16_t i;
	for (i = 0; i <600; i++)
    {
      BUZZER_ON();
      Delay_us(200);
      BUZZER_OFF();
      Delay_us(200);
    }
}


