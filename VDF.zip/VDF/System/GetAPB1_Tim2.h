#ifndef __GETAPB1_TIM2_H
#define __GETAPB1_TIM2_H

void Timer_Init(void);

#endif
