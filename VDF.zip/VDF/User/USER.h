#ifndef __USER_H
#define __USER_H
#include "stm32f10x.h" // Device header

extern unsigned char KeyNum,TimerSetSelect,MODE,Set_flag,TimeSetFlash;

void Sys_Soft_Reset(void);

void TIM2_IRQHandler(void);

void ShowTimeYMD(void);

void ShowTimeHMS(void);

void TimeSetYMD(void);

void TimeSetHMS(void);

int TimeTxxDxx(void);

#endif
