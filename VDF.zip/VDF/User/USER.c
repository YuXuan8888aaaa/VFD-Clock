#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "VFD.h"
#include "DS3231.h" 
#include "Key.h"
#include "BUZZER.h"
#include "GetAPB1_Tim2.h"

unsigned char TimerSetSelect,MODE,Set_flag,TimeSetFlash;


void Sys_Soft_Reset(void)  //������
{
    SCB->AIRCR = 0x05FA0000 | (u32)0x04;
}

void TIM2_IRQHandler(void)
{
	if (TIM_GetITStatus(TIM2, TIM_IT_Update) == SET)		//�ж��Ƿ���TIM2�ĸ����¼��������ж�
	{
		TimeSetFlash=!TimeSetFlash;
        
		TIM_ClearITPendingBit(TIM2, TIM_IT_Update);			//���TIM2�����¼����жϱ�־λ
	}
}


void ShowTimeHMS(void)
{
    I2C_DS3231_getTime();
    
    S0801_ShowNum( 0,DS3231_Time[4],2);
    S0801_WriteStr(2,":");
    S0801_ShowNum( 3,DS3231_Time[5],2);  
    S0801_WriteStr(5,":");
    S0801_ShowNum( 6,DS3231_Time[6],2);

}
void ShowTimeYMD(void)
{
    I2C_DS3231_getTime();
    
    S0801_ShowNum( 0,DS3231_Time[0],2);
    S0801_WriteStr(2,"-");
    S0801_ShowNum( 3,DS3231_Time[1],2);  
    S0801_WriteStr(5,"-");
    S0801_ShowNum( 6,DS3231_Time[2],2);

}

void TimeSetHMS(void)
{   
    S0801_WriteStr(0,"        ");
    Delay_ms(100);
    while(1)
    {   
//        KeyNum = Key_GetNum();
        
        if (TimerSetSelect ==0) TimerSetSelect = 4; //�������ƶ�λ
        if (TimerSetSelect ==1) TimerSetSelect = 4;
        if (TimerSetSelect ==2) TimerSetSelect = 4;
        if (TimerSetSelect ==3) TimerSetSelect = 4;
        
        if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_9)==RESET)
            {
                BUZZ_P11();
                I2C_DS3231_SetTime();
                
                Sys_Soft_Reset();
                
            } 
            
        if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_3)==RESET)
            {
                TimerSetSelect++;
                BUZZ_P11();
                if (TimerSetSelect ==7) TimerSetSelect = 4;
            }
            
        if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_4)==RESET)
            {
                DS3231_Time[TimerSetSelect]++;
                if(DS3231_Time[4]>23){DS3231_Time[4]=0;}//ʱԽ���ж�
                if(DS3231_Time[5]>59){DS3231_Time[5]=0;}//��Խ���ж�
                if(DS3231_Time[6]>59){DS3231_Time[6]=0;}//��Խ���ж�
                BUZZ_P1();
            }
            
        if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_8)==RESET)
            {
                DS3231_Time[TimerSetSelect]--;
                if(DS3231_Time[4]>23){DS3231_Time[4]=23;}//ʱԽ���ж�
                if(DS3231_Time[5]>59){DS3231_Time[5]=59;}//��Խ���ж�
                if(DS3231_Time[6]>59){DS3231_Time[6]=59;}//��Խ���ж�
                BUZZ_P1();
            }
        
        S0801_WriteStr(2,":");  
        S0801_WriteStr(5,":");
        if((TimerSetSelect==4 && TimeSetFlash) == 1){S0801_WriteStr(0,"  ");}
        else {S0801_ShowNum( 0,DS3231_Time[4],2);}
        if((TimerSetSelect==5 && TimeSetFlash) == 1){S0801_WriteStr(3,"  ");}
        else {S0801_ShowNum( 3,DS3231_Time[5],2); }
        if((TimerSetSelect==6 && TimeSetFlash) == 1){S0801_WriteStr(6,"  ");}
        else {S0801_ShowNum( 6,DS3231_Time[6],2);}
    }
}

void TimeSetYMD(void)
{
    S0801_WriteStr(0,"        ");
    Delay_ms(100);
    while(1)
      {   
//          KeyNum = Key_GetNum();
          if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_9)==RESET)
              {
                  BUZZ_P11();
                  I2C_DS3231_SetTime();

                  Sys_Soft_Reset();
              } 
          if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_3)==RESET)
          {
                  TimerSetSelect++;
                  BUZZ_P11();
                  if (TimerSetSelect == 3) TimerSetSelect = 0;
          }
          
          if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_4)==RESET)
              {
                  DS3231_Time[TimerSetSelect]++;
                  if(DS3231_Time[0]>99){DS3231_Time[0]=0;}//��Խ���ж�
                  if(DS3231_Time[1]>12){DS3231_Time[1]=1;}//��Խ���ж�
                      if( DS3231_Time[1]==1 || DS3231_Time[1]==3 || DS3231_Time[1]==5 || DS3231_Time[1]==7 || 
                          DS3231_Time[1]==8 || DS3231_Time[1]==10 || DS3231_Time[1]==12)//��Խ���ж�
                              {
                                  if(DS3231_Time[2]>31){DS3231_Time[2]=1;}//����
                              }
                      else if(DS3231_Time[1]==4 || DS3231_Time[1]==6 || DS3231_Time[1]==9 || DS3231_Time[1]==11)
                              {
                                  if(DS3231_Time[2]>30){DS3231_Time[2]=1;}//С��
                              }
                      else if(DS3231_Time[1]==2)
                              {
                                  if(DS3231_Time[0]%4==0)
                                      {
                                          if(DS3231_Time[2]>29){DS3231_Time[2]=1;}//����2��
                                      }
                                  else
                                      {
                                          if(DS3231_Time[2]>28){DS3231_Time[2]=1;}//ƽ��2��
                                      }
                              }
                  BUZZ_P1();
              }
              
          if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_8)==RESET)
              {
                  DS3231_Time[TimerSetSelect]--;
                  if(DS3231_Time[0]>99){DS3231_Time[0]=99;}//��Խ���ж�
                  if(DS3231_Time[1]>12){DS3231_Time[1]=12;}//��Խ���ж�
                  if(DS3231_Time[1]<1){DS3231_Time[1]=12;}//��Խ���ж�
                  if( DS3231_Time[1]==1 || DS3231_Time[1]==3 || DS3231_Time[1]==5 || DS3231_Time[1]==7 || 
                      DS3231_Time[1]==8 || DS3231_Time[1]==10 || DS3231_Time[1]==12)//��Խ���ж�
                      {
                          if(DS3231_Time[2]<1){DS3231_Time[2]=31;}//����
                          if(DS3231_Time[2]>31){DS3231_Time[2]=1;}
                      }
                  else if(DS3231_Time[1]==4 || DS3231_Time[1]==6 || DS3231_Time[1]==9 || DS3231_Time[1]==11)
                      {
                          if(DS3231_Time[2]<1){DS3231_Time[2]=30;}//С��
                          if(DS3231_Time[2]>30){DS3231_Time[2]=1;}
                      }
                  else if(DS3231_Time[1]==2)
                  {
                      if(DS3231_Time[0]%4==0)
                          {
                              if(DS3231_Time[2]<1){DS3231_Time[2]=29;}//����2��
                              if(DS3231_Time[2]>29){DS3231_Time[2]=1;}
                          }
                      else
                          {
                              if(DS3231_Time[2]<1){DS3231_Time[2]=28;}//ƽ��2��
                              if(DS3231_Time[2]>28){DS3231_Time[2]=1;}
                          }
                  }
                  BUZZ_P1();
                }
      
          
          S0801_WriteStr(2,"-");     
          S0801_WriteStr(5,"-");                        
          if((TimerSetSelect==0 && TimeSetFlash) == 1){S0801_WriteStr(0,"  ");}
          else {S0801_ShowNum( 0,DS3231_Time[0],2);}
          if((TimerSetSelect==1 && TimeSetFlash) == 1){S0801_WriteStr(3,"  ");}
          else {S0801_ShowNum( 3,DS3231_Time[1],2); }
          if((TimerSetSelect==2 && TimeSetFlash) == 1){S0801_WriteStr(6,"  ");}
          else {S0801_ShowNum( 6,DS3231_Time[2],2);}
      }
}


int TimeTxxDxx()
{   
    S0801_WriteStr(0,">SetTime");
    Delay_ms(800);
    S0801_WriteStr(0,"        ");
    S0801_WriteStr(0," STD");
    S0801_WriteStr(4," STT");
    
    while(1)
       {
//           KeyNum = Key_GetNum();
  		if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_3)==RESET)//���Ƽ�
            {
                BUZZ_P1();
                Set_flag++;
                if(Set_flag==3) Set_flag=1;                
            }
		if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_9)==RESET)//ѡ���
            {
                BUZZ_P11();
                return Set_flag;
            }   
            
        if(Set_flag == 1)
            {
                 S0801_WriteStr(0,">");
                 S0801_WriteStr(4," ");
            }
           
        if(Set_flag == 2)
            {
                 S0801_WriteStr(0," ");
                 S0801_WriteStr(4,">");
            }
        }
}



