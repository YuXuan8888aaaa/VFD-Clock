#include "stm32f10x.h"                  // Device header
#include "GetAPB1_Tim2.h"
#include "Delay.h"
#include "VFD.h"
#include "DS3231.h" 
#include "Key.h"
#include "BUZZER.h"
#include "USER.h"
#include "OLED.h"
#include "LED.h"

uint8_t Brightness;
        
int main(void)
{ 
    Key_Init();
    Delay_ms(500);
    DS3231_Init();
    VFD_IO_INIT();
    VFD_Init();
    OLED_Init();
    LED_Init();
    
    BUZZER_Init();    
    BUZZ_P1();
    Delay_ms(500);
    Timer_Init();
    
    OLED_ShowString(1,3,"VFD_PCB_Test");
    OLED_ShowString(2,6,"V0.02");
    Delay_ms(800);
    S0801_WriteStr(0," HELLO! ");
    Delay_ms(200);

    Brightness = 255;
    S0801_Brightness(Brightness);
          
  while(1)
	{   
       
        OLED_ShowNum(3,5,DS3231_Time[0],2);
        OLED_ShowString(3,7,"-");
        OLED_ShowNum(3,8,DS3231_Time[1],2);
        OLED_ShowString(3,10,"-");
        OLED_ShowNum(3,11,DS3231_Time[2],2);
        //...............................//
        OLED_ShowNum(4,5,DS3231_Time[4],2);
        OLED_ShowString(4,7,":");
        OLED_ShowNum(4,8,DS3231_Time[5],2);
        OLED_ShowString(4,10,":");
        OLED_ShowNum(4,11,DS3231_Time[6],2);
        
        LED_All_OFF();

        
//        KeyNum = Key_GetNum();
        
        if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_9)==RESET)
             {  
                 BUZZ_P11();
                 TimeTxxDxx();
             }
             
         if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_4)==RESET)
             {  
                 MODE = 1;
                 BUZZ_P1();
             }
         if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_8)==RESET)
             {  
                 MODE = 0;
                 BUZZ_P1();                 
             }
         if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_3)==RESET)					
		{   
            BUZZ_P1();
			Brightness -= 32;					
			if (Brightness <= 0)				
			{
				Brightness = 255;				
			}
		}
        switch(MODE)
             {
             case 0:
                 ShowTimeHMS();
             break;         
             case 1:
                 ShowTimeYMD();       
             break;
             }
        if(Set_flag == 1) TimeSetYMD();
        if(Set_flag == 2) TimeSetHMS();
             
        S0801_Brightness(Brightness);
                    
    }
	
}



